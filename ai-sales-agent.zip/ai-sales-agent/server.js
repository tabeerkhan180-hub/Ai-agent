// ai-sales-agent/server.js
//
// Autonomous AI sales agent.
// - Reads leads from leads.json
// - Writes a hyper-personalized cold email per lead with Claude
// - Sends via SMTP (Gmail app password) with human-like random delays
// - Respects a daily limit, per-lead attempt cap, and a suppression list
// - Optionally scans IMAP for replies and flags interested leads
// - Exposes a small, secret-key protected HTTP control panel + JSON API
//
// CLI flags:
//   --run-now            start a sending campaign immediately on boot
//   --dry-run            generate emails but never actually send (also env DRY_RUN=true)
//   --limit=N            override DAILY_LIMIT for this run
//   --exit-when-done     process.exit(0) after the campaign/reply scan finishes
//   --check-replies      run the IMAP reply scan
//
// Everything is file-based (no DB) so it is trivially portable.

import "dotenv/config";
import fs from "node:fs";
import fsp from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import express from "express";
import nodemailer from "nodemailer";
import Anthropic from "@anthropic-ai/sdk";
import { ImapFlow } from "imapflow";

/* ------------------------------------------------------------------ */
/* Paths & constants                                                  */
/* ------------------------------------------------------------------ */

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, "data");
const LEADS_FILE = path.join(__dirname, "leads.json");

const FILES = {
  state: path.join(DATA_DIR, "state.json"),
  sentLog: path.join(DATA_DIR, "sent-log.jsonl"),
  interested: path.join(DATA_DIR, "interested.json"),
  suppression: path.join(DATA_DIR, "suppression.json"),
};

/* ------------------------------------------------------------------ */
/* Config (env)                                                       */
/* ------------------------------------------------------------------ */

const argv = process.argv.slice(2);
const hasFlag = (name) => argv.includes(`--${name}`);
const getFlag = (name, fallback) => {
  const hit = argv.find((a) => a.startsWith(`--${name}=`));
  return hit ? hit.split("=").slice(1).join("=") : fallback;
};

const bool = (v, d = false) =>
  v === undefined ? d : ["1", "true", "yes", "on"].includes(String(v).toLowerCase());
const int = (v, d) => {
  const n = Number.parseInt(v, 10);
  return Number.isFinite(n) ? n : d;
};

const CONFIG = {
  claudeModel: process.env.CLAUDE_MODEL || "claude-sonnet-4-20250514",
  anthropicKey: process.env.ANTHROPIC_API_KEY || "",

  smtp: {
    host: process.env.SMTP_HOST || "smtp.gmail.com",
    port: int(process.env.SMTP_PORT, 465),
    secure: bool(process.env.SMTP_SECURE, true),
    user: process.env.SMTP_USER || "",
    pass: process.env.SMTP_PASS || "",
  },

  sender: {
    fromName: process.env.FROM_NAME || "Sales",
    fromEmail: process.env.FROM_EMAIL || process.env.SMTP_USER || "",
    replyTo: process.env.REPLY_TO || process.env.FROM_EMAIL || "",
    company: process.env.COMPANY_NAME || "",
    address: process.env.COMPANY_ADDRESS || "",
    calendar: process.env.CALENDAR_LINK || "",
    phone: process.env.SENDER_PHONE || "",
  },

  campaign: {
    dailyLimit: int(getFlag("limit", process.env.DAILY_LIMIT), 40),
    minDelayMs: int(process.env.MIN_DELAY_MS, 45000),
    maxDelayMs: int(process.env.MAX_DELAY_MS, 120000),
    maxAttempts: int(process.env.MAX_ATTEMPTS, 3),
    dryRun: hasFlag("dry-run") || bool(process.env.DRY_RUN, false),
  },

  server: {
    port: int(process.env.PORT, 3000),
    publicUrl: process.env.PUBLIC_URL || `http://localhost:${int(process.env.PORT, 3000)}`,
    secretKey: process.env.SECRET_KEY || "",
    cronSecret: process.env.CRON_SECRET || "",
  },

  imap: {
    enabled: bool(process.env.ENABLE_REPLY_SCAN, false),
    host: process.env.IMAP_HOST || "imap.gmail.com",
    port: int(process.env.IMAP_PORT, 993),
    user: process.env.IMAP_USER || process.env.SMTP_USER || "",
    pass: process.env.IMAP_PASS || process.env.SMTP_PASS || "",
  },

  flags: {
    runNow: hasFlag("run-now"),
    exitWhenDone: hasFlag("exit-when-done"),
    checkReplies: hasFlag("check-replies"),
  },
};

/* ------------------------------------------------------------------ */
/* Tiny logger                                                        */
/* ------------------------------------------------------------------ */

const ts = () => new Date().toISOString();
const log = {
  info: (...a) => console.log(`[${ts()}]`, ...a),
  warn: (...a) => console.warn(`[${ts()}] WARN`, ...a),
  err: (...a) => console.error(`[${ts()}] ERROR`, ...a),
};

/* ------------------------------------------------------------------ */
/* File helpers                                                       */
/* ------------------------------------------------------------------ */

async function ensureData() {
  await fsp.mkdir(DATA_DIR, { recursive: true });
  if (!fs.existsSync(FILES.state)) await writeJson(FILES.state, defaultState());
  if (!fs.existsSync(FILES.interested)) await writeJson(FILES.interested, []);
  if (!fs.existsSync(FILES.suppression)) await writeJson(FILES.suppression, []);
  if (!fs.existsSync(FILES.sentLog)) await fsp.writeFile(FILES.sentLog, "");
}

function defaultState() {
  return {
    // per-lead tracking keyed by lead id
    leads: {}, // { [id]: { status, attempts, lastAttemptAt, lastError, messageId, unsubToken } }
    // per-day counters keyed by YYYY-MM-DD
    daily: {}, // { [date]: sentCount }
    lastRunAt: null,
    createdAt: ts(),
  };
}

async function readJson(file, fallback) {
  try {
    const raw = await fsp.readFile(file, "utf8");
    return raw.trim() ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

async function writeJson(file, data) {
  const tmp = `${file}.tmp`;
  await fsp.writeFile(tmp, JSON.stringify(data, null, 2));
  await fsp.rename(tmp, file);
}

async function appendJsonl(file, obj) {
  await fsp.appendFile(file, JSON.stringify(obj) + "\n");
}

/* ------------------------------------------------------------------ */
/* State access (serialized to avoid concurrent write races)          */
/* ------------------------------------------------------------------ */

let stateWriteChain = Promise.resolve();

async function updateState(mutator) {
  stateWriteChain = stateWriteChain.then(async () => {
    const state = await readJson(FILES.state, defaultState());
    const result = await mutator(state);
    await writeJson(FILES.state, state);
    return result;
  });
  return stateWriteChain;
}

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

/* ------------------------------------------------------------------ */
/* Leads                                                              */
/* ------------------------------------------------------------------ */

async function loadLeads() {
  const leads = await readJson(LEADS_FILE, []);
  if (!Array.isArray(leads)) throw new Error("leads.json must be a JSON array");
  return leads.filter((l) => l && l.email && l.id);
}

function normalizeEmail(email) {
  return String(email || "").trim().toLowerCase();
}

/* ------------------------------------------------------------------ */
/* Suppression list                                                   */
/* ------------------------------------------------------------------ */

async function isSuppressed(email) {
  const list = await readJson(FILES.suppression, []);
  const set = new Set(list.map((e) => normalizeEmail(e.email || e)));
  return set.has(normalizeEmail(email));
}

async function addSuppression(email, reason) {
  const list = await readJson(FILES.suppression, []);
  const norm = normalizeEmail(email);
  if (!list.some((e) => normalizeEmail(e.email || e) === norm)) {
    list.push({ email: norm, reason: reason || "unsubscribe", at: ts() });
    await writeJson(FILES.suppression, list);
  }
}

/* ------------------------------------------------------------------ */
/* Unsubscribe tokens                                                 */
/* ------------------------------------------------------------------ */

function makeUnsubToken(leadId, email) {
  const secret = CONFIG.server.secretKey || "fallback-secret";
  const h = crypto
    .createHmac("sha256", secret)
    .update(`${leadId}:${normalizeEmail(email)}`)
    .digest("hex")
    .slice(0, 24);
  return h;
}

function unsubscribeUrl(leadId, email) {
  const token = makeUnsubToken(leadId, email);
  const u = new URL("/unsubscribe", CONFIG.server.publicUrl);
  u.searchParams.set("id", leadId);
  u.searchParams.set("e", normalizeEmail(email));
  u.searchParams.set("t", token);
  return u.toString();
}

/* ------------------------------------------------------------------ */
/* Claude email generation (per-lead personalized)                    */
/* ------------------------------------------------------------------ */

let anthropic = null;
function getAnthropic() {
  if (!anthropic) {
    if (!CONFIG.anthropicKey) throw new Error("ANTHROPIC_API_KEY is not set");
    anthropic = new Anthropic({ apiKey: CONFIG.anthropicKey });
  }
  return anthropic;
}

const SYSTEM_PROMPT = `You are an expert B2B cold-email copywriter for a digital agency.

The agency sells two services:
1. Modern, mobile-responsive websites with online booking / ordering.
2. An AI voice receptionist that answers phone calls 24/7, books appointments, and never misses a lead.

Your job: write ONE short, hyper-personalized cold email to a specific local business owner.

Hard rules:
- Reference the SPECIFIC problem in the lead notes (e.g. no website, missed calls, DM-only bookings, high delivery-app commission). Make it obvious this was written for them, not a template.
- Tone: warm, direct, human, peer-to-peer. NOT salesy or corporate. No hype words ("revolutionary", "game-changer", "unlock").
- Length: 70-120 words in the body. Short paragraphs / single sentences. Easy to read on a phone.
- Exactly ONE clear call to action: a quick 15-minute call via the calendar link.
- Do NOT invent facts, statistics, prices, or fake claims. Do NOT promise specific numbers.
- Do NOT use the recipient's email address in the copy. Address them by owner name if available, otherwise the business name.
- No emojis. No markdown. Plain sentences only.

Return STRICT JSON only, no prose, no code fences:
{"subject": "...", "body": "..."}

- "subject": under 60 characters, lowercase-ish, curiosity or specific-problem based, NOT clickbait, no ALL CAPS, no exclamation spam.
- "body": the email body text ONLY. Do NOT include a subject line, greeting salutation is fine, but do NOT include a signature, calendar link, address, or unsubscribe line — those are appended automatically. Use \\n for line breaks.`;

function buildUserPrompt(lead) {
  const s = CONFIG.sender;
  return `Write the cold email for this lead.

SENDER:
- Name: ${s.fromName}
- Agency: ${s.company || "our agency"}

LEAD:
- Business: ${lead.business || "(unknown)"}
- Owner: ${lead.owner || "(unknown)"}
- Niche: ${lead.niche || "(unknown)"}
- City: ${lead.city || "(unknown)"}
- Research notes: ${lead.notes || "(none)"}

Pick whichever of the two services (website and/or AI voice receptionist) most directly solves the problem in the notes. Lead with their specific pain point.`;
}

function extractJson(text) {
  // Strip code fences if the model added them, then grab the first {...} block.
  const cleaned = text.replace(/```json/gi, "").replace(/```/g, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start === -1 || end === -1) throw new Error("No JSON object found in model output");
  return JSON.parse(cleaned.slice(start, end + 1));
}

async function generateEmail(lead) {
  const client = getAnthropic();
  const res = await client.messages.create({
    model: CONFIG.claudeModel,
    max_tokens: 700,
    temperature: 0.7,
    system: SYSTEM_PROMPT,
    messages: [{ role: "user", content: buildUserPrompt(lead) }],
  });

  const text = res.content
    .filter((c) => c.type === "text")
    .map((c) => c.text)
    .join("\n");

  const parsed = extractJson(text);
  let subject = String(parsed.subject || "").trim();
  let body = String(parsed.body || "").trim();

  if (!subject || !body) throw new Error("Model returned empty subject or body");
  if (subject.length > 90) subject = subject.slice(0, 90);

  return { subject, body };
}

/* ------------------------------------------------------------------ */
/* Compose full email (signature + compliance footer)                 */
/* ------------------------------------------------------------------ */

function composeEmail(lead, ai) {
  const s = CONFIG.sender;
  const unsub = unsubscribeUrl(lead.id, lead.email);

  const signatureLines = [
    "",
    "—",
    s.fromName,
    s.company,
    s.phone ? s.phone : null,
    s.calendar ? `Book a 15-min call: ${s.calendar}` : null,
  ].filter(Boolean);

  const footerLines = [
    "",
    "",
    "You are receiving this one-time email because your business was listed publicly in your area.",
    s.company && s.address ? `${s.company}, ${s.address}` : (s.address || s.company || ""),
    `Not interested? Unsubscribe here and we will never contact you again: ${unsub}`,
  ].filter(Boolean);

  const text = [ai.body, ...signatureLines, ...footerLines].join("\n");

  const html = renderHtml(ai.body, signatureLines, footerLines, unsub);

  return { subject: ai.subject, text, html, unsub };
}

function esc(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function renderHtml(body, signatureLines, footerLines, unsub) {
  const bodyHtml = esc(body).replace(/\n/g, "<br>");
  const sigHtml = signatureLines
    .map((l) => (l === "—" ? "<hr style='border:none;border-top:1px solid #ddd;margin:16px 0'>" : esc(l)))
    .join("<br>");
  const footerHtml = footerLines
    .map((l) =>
      l.includes(unsub)
        ? `Not interested? <a href="${esc(unsub)}">Unsubscribe</a> and we will never contact you again.`
        : esc(l)
    )
    .join("<br>");

  return `<!doctype html><html><body style="margin:0;padding:0;background:#f6f6f6">
<div style="max-width:560px;margin:0 auto;padding:24px;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;font-size:15px;line-height:1.6;color:#1a1a1a">
<div>${bodyHtml}</div>
<div style="margin-top:12px;color:#444">${sigHtml}</div>
<div style="margin-top:20px;font-size:12px;color:#999">${footerHtml}</div>
</div></body></html>`;
}

/* ------------------------------------------------------------------ */
/* SMTP transport                                                     */
/* ------------------------------------------------------------------ */

let transporter = null;
function getTransport() {
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: CONFIG.smtp.host,
      port: CONFIG.smtp.port,
      secure: CONFIG.smtp.secure,
      auth: { user: CONFIG.smtp.user, pass: CONFIG.smtp.pass },
    });
  }
  return transporter;
}

async function sendEmail(lead, composed) {
  const s = CONFIG.sender;
  const info = await getTransport().sendMail({
    from: `"${s.fromName}" <${s.fromEmail}>`,
    to: lead.owner ? `"${lead.owner}" <${lead.email}>` : lead.email,
    replyTo: s.replyTo,
    subject: composed.subject,
    text: composed.text,
    html: composed.html,
    headers: {
      "List-Unsubscribe": `<${composed.unsub}>`,
      "List-Unsubscribe-Post": "List-Unsubscribe=One-Click",
    },
  });
  return info;
}

/* ------------------------------------------------------------------ */
/* Delay helper (human-like jitter)                                   */
/* ------------------------------------------------------------------ */

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function randomDelay() {
  const { minDelayMs, maxDelayMs } = CONFIG.campaign;
  const lo = Math.min(minDelayMs, maxDelayMs);
  const hi = Math.max(minDelayMs, maxDelayMs);
  return lo + Math.floor(Math.random() * (hi - lo + 1));
}

/* ------------------------------------------------------------------ */
/* Campaign runner                                                    */
/* ------------------------------------------------------------------ */

let campaignRunning = false;

async function sentToday() {
  const state = await readJson(FILES.state, defaultState());
  return state.daily?.[todayKey()] || 0;
}

async function pickSendableLeads(limit) {
  const [leads, state] = await Promise.all([
    loadLeads(),
    readJson(FILES.state, defaultState()),
  ]);

  const out = [];
  for (const lead of leads) {
    if (out.length >= limit) break;
    const rec = state.leads?.[lead.id];
    const status = rec?.status;
    if (status === "sent" || status === "replied" || status === "unsubscribed") continue;
    if ((rec?.attempts || 0) >= CONFIG.campaign.maxAttempts) continue;
    if (await isSuppressed(lead.email)) continue;
    out.push(lead);
  }
  return out;
}

async function runCampaign({ trigger = "manual" } = {}) {
  if (campaignRunning) {
    log.warn("Campaign already running; ignoring trigger:", trigger);
    return { ok: false, reason: "already-running" };
  }
  campaignRunning = true;
  const summary = { attempted: 0, sent: 0, failed: 0, skipped: 0, dryRun: CONFIG.campaign.dryRun };

  try {
    validateSendConfig();

    const already = await sentToday();
    const remaining = Math.max(0, CONFIG.campaign.dailyLimit - already);
    if (remaining === 0) {
      log.info(`Daily limit reached (${CONFIG.campaign.dailyLimit}). Nothing to do.`);
      return { ok: true, summary, note: "daily-limit-reached" };
    }

    const leads = await pickSendableLeads(remaining);
    log.info(
      `Campaign start (${trigger}). Sendable: ${leads.length}, remaining today: ${remaining}, dryRun: ${CONFIG.campaign.dryRun}`
    );

    for (let i = 0; i < leads.length; i++) {
      const lead = leads[i];
      summary.attempted++;

      // Re-check suppression right before send (could have changed mid-run).
      if (await isSuppressed(lead.email)) {
        summary.skipped++;
        continue;
      }

      try {
        const ai = await generateEmail(lead);
        const composed = composeEmail(lead, ai);

        let messageId = null;
        if (CONFIG.campaign.dryRun) {
          log.info(`[DRY RUN] Would send to ${lead.email} | subject: ${composed.subject}`);
          console.log("---\n" + composed.text + "\n---");
        } else {
          const info = await sendEmail(lead, composed);
          messageId = info.messageId;
          log.info(`Sent to ${lead.email} | ${composed.subject} | id: ${messageId}`);
        }

        await recordSend(lead, composed, messageId);
        summary.sent++;
      } catch (e) {
        summary.failed++;
        log.err(`Failed for ${lead.email}:`, e.message);
        await recordFailure(lead, e.message);
      }

      // Delay between sends (skip after the last one).
      if (i < leads.length - 1) {
        const d = randomDelay();
        log.info(`Waiting ${(d / 1000).toFixed(0)}s before next send...`);
        await sleep(d);
      }
    }

    await updateState((st) => {
      st.lastRunAt = ts();
    });

    log.info(
      `Campaign done. sent=${summary.sent} failed=${summary.failed} skipped=${summary.skipped}`
    );
    return { ok: true, summary };
  } catch (e) {
    log.err("Campaign aborted:", e.message);
    return { ok: false, error: e.message, summary };
  } finally {
    campaignRunning = false;
  }
}

async function recordSend(lead, composed, messageId) {
  const date = todayKey();
  await updateState((st) => {
    const rec = st.leads[lead.id] || { attempts: 0 };
    rec.status = CONFIG.campaign.dryRun ? "dry-run" : "sent";
    rec.attempts = (rec.attempts || 0) + 1;
    rec.lastAttemptAt = ts();
    rec.lastError = null;
    rec.messageId = messageId;
    rec.subject = composed.subject;
    st.leads[lead.id] = rec;
    if (!CONFIG.campaign.dryRun) {
      st.daily[date] = (st.daily[date] || 0) + 1;
    }
  });

  await appendJsonl(FILES.sentLog, {
    at: ts(),
    leadId: lead.id,
    business: lead.business,
    email: lead.email,
    subject: composed.subject,
    messageId,
    dryRun: CONFIG.campaign.dryRun,
  });
}

async function recordFailure(lead, message) {
  await updateState((st) => {
    const rec = st.leads[lead.id] || { attempts: 0 };
    rec.attempts = (rec.attempts || 0) + 1;
    rec.lastAttemptAt = ts();
    rec.lastError = message;
    rec.status = rec.attempts >= CONFIG.campaign.maxAttempts ? "failed" : "retry";
    st.leads[lead.id] = rec;
  });
}

/* ------------------------------------------------------------------ */
/* IMAP reply scanning + interested-lead detection                    */
/* ------------------------------------------------------------------ */

const NEGATIVE_PATTERNS = [
  /\bunsubscribe\b/i,
  /\bremove me\b/i,
  /\bstop emailing\b/i,
  /\bnot interested\b/i,
  /\bno thanks\b/i,
  /\bdo not contact\b/i,
  /\bleave me alone\b/i,
];

const POSITIVE_PATTERNS = [
  /\binterested\b/i,
  /\btell me more\b/i,
  /\bmore info\b/i,
  /\bhow much\b/i,
  /\bprice\b|\bpricing\b|\bcost\b|\bquote\b/i,
  /\bcall\b|\bschedule\b|\bbook\b|\bmeeting\b|\bavailable\b/i,
  /\byes\b/i,
  /\bsounds good\b/i,
  /\blet'?s (talk|chat|do it)\b/i,
];

function classifyReply(text) {
  const t = String(text || "");
  if (NEGATIVE_PATTERNS.some((re) => re.test(t))) return "negative";
  if (POSITIVE_PATTERNS.some((re) => re.test(t))) return "positive";
  return "neutral";
}

async function buildEmailToLeadIndex() {
  const leads = await loadLeads();
  const map = new Map();
  for (const l of leads) map.set(normalizeEmail(l.email), l);
  return map;
}

let replyScanRunning = false;

async function checkReplies() {
  if (!CONFIG.imap.enabled) {
    log.warn("Reply scanning is disabled (ENABLE_REPLY_SCAN=false).");
    return { ok: false, reason: "disabled" };
  }
  if (replyScanRunning) return { ok: false, reason: "already-running" };
  replyScanRunning = true;

  const result = { processed: 0, positive: 0, negative: 0, neutral: 0, unsubscribed: 0 };
  const client = new ImapFlow({
    host: CONFIG.imap.host,
    port: CONFIG.imap.port,
    secure: true,
    auth: { user: CONFIG.imap.user, pass: CONFIG.imap.pass },
    logger: false,
  });

  try {
    await client.connect();
    const lock = await client.getMailboxLock("INBOX");
    try {
      const emailIndex = await buildEmailToLeadIndex();

      // Only unseen messages from the last 14 days.
      const since = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000);
      const uids = await client.search({ seen: false, since });
      if (!uids || uids.length === 0) {
        log.info("No new unread replies.");
        return { ok: true, ...result };
      }

      for await (const msg of client.fetch(uids, { envelope: true, source: true })) {
        const fromAddr = normalizeEmail(msg.envelope?.from?.[0]?.address);
        const lead = emailIndex.get(fromAddr);
        if (!lead) continue; // not from a known lead

        const raw = msg.source ? msg.source.toString("utf8") : "";
        const bodyText = extractPlainBody(raw);
        const verdict = classifyReply(
          `${msg.envelope?.subject || ""}\n${bodyText}`
        );

        result.processed++;
        result[verdict === "positive" ? "positive" : verdict === "negative" ? "negative" : "neutral"]++;

        if (verdict === "negative") {
          await addSuppression(lead.email, "reply-optout");
          await updateState((st) => {
            const rec = st.leads[lead.id] || { attempts: 0 };
            rec.status = "unsubscribed";
            st.leads[lead.id] = rec;
          });
          result.unsubscribed++;
          log.info(`Opt-out reply from ${lead.email} -> suppressed.`);
        } else {
          await updateState((st) => {
            const rec = st.leads[lead.id] || { attempts: 0 };
            rec.status = "replied";
            rec.replyVerdict = verdict;
            rec.repliedAt = ts();
            st.leads[lead.id] = rec;
          });

          if (verdict === "positive") {
            await addInterested(lead, {
              subject: msg.envelope?.subject || "",
              snippet: bodyText.slice(0, 500),
            });
            log.info(`INTERESTED lead: ${lead.business} <${lead.email}>`);
          }
        }

        // Mark as read so we don't reprocess.
        try {
          await client.messageFlagsAdd(msg.uid, ["\\Seen"], { uid: true });
        } catch {
          /* non-fatal */
        }
      }
    } finally {
      lock.release();
    }
    log.info(
      `Reply scan done. processed=${result.processed} positive=${result.positive} negative=${result.negative}`
    );
    return { ok: true, ...result };
  } catch (e) {
    log.err("Reply scan failed:", e.message);
    return { ok: false, error: e.message, ...result };
  } finally {
    try {
      await client.logout();
    } catch {
      /* ignore */
    }
    replyScanRunning = false;
  }
}

async function addInterested(lead, meta) {
  const list = await readJson(FILES.interested, []);
  if (!list.some((x) => x.leadId === lead.id)) {
    list.push({
      leadId: lead.id,
      business: lead.business,
      owner: lead.owner,
      email: lead.email,
      niche: lead.niche,
      city: lead.city,
      phone: lead.phone || null,
      subject: meta.subject,
      snippet: meta.snippet,
      detectedAt: ts(),
    });
    await writeJson(FILES.interested, list);
  }
}

// Very small text/plain extractor from a raw RFC822 message.
function extractPlainBody(raw) {
  if (!raw) return "";
  const boundaryMatch = raw.match(/boundary="?([^"\r\n;]+)"?/i);
  const headerEnd = raw.indexOf("\r\n\r\n");
  const afterHeaders = headerEnd === -1 ? raw : raw.slice(headerEnd + 4);

  if (!boundaryMatch) return decodeMaybe(afterHeaders).slice(0, 5000);

  const boundary = "--" + boundaryMatch[1];
  const parts = afterHeaders.split(boundary);
  // Prefer the first text/plain part.
  for (const part of parts) {
    if (/content-type:\s*text\/plain/i.test(part)) {
      const idx = part.indexOf("\r\n\r\n");
      if (idx !== -1) return decodeMaybe(part.slice(idx + 4)).slice(0, 5000);
    }
  }
  // Fallback: strip HTML from first text/html part.
  for (const part of parts) {
    if (/content-type:\s*text\/html/i.test(part)) {
      const idx = part.indexOf("\r\n\r\n");
      if (idx !== -1)
        return decodeMaybe(part.slice(idx + 4))
          .replace(/<[^>]+>/g, " ")
          .slice(0, 5000);
    }
  }
  return decodeMaybe(afterHeaders).slice(0, 5000);
}

function decodeMaybe(s) {
  // Handle quoted-printable soft line breaks / =XX escapes lightly.
  return String(s)
    .replace(/=\r?\n/g, "")
    .replace(/=([A-Fa-f0-9]{2})/g, (_, h) => String.fromCharCode(parseInt(h, 16)))
    .trim();
}

/* ------------------------------------------------------------------ */
/* Validation                                                         */
/* ------------------------------------------------------------------ */

function validateSendConfig() {
  const missing = [];
  if (!CONFIG.anthropicKey) missing.push("ANTHROPIC_API_KEY");
  if (!CONFIG.campaign.dryRun) {
    if (!CONFIG.smtp.user) missing.push("SMTP_USER");
    if (!CONFIG.smtp.pass) missing.push("SMTP_PASS");
    if (!CONFIG.sender.fromEmail) missing.push("FROM_EMAIL");
  }
  if (!CONFIG.sender.company) missing.push("COMPANY_NAME");
  if (!CONFIG.sender.address) missing.push("COMPANY_ADDRESS (required by anti-spam law)");
  if (missing.length) {
    throw new Error(`Missing required config: ${missing.join(", ")}`);
  }
}

/* ------------------------------------------------------------------ */
/* HTTP server                                                        */
/* ------------------------------------------------------------------ */

function timingSafeEqual(a, b) {
  const ba = Buffer.from(String(a || ""));
  const bb = Buffer.from(String(b || ""));
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}

function requireSecret(req, res, next) {
  const provided =
    req.get("x-secret-key") ||
    req.query.key ||
    (req.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (!CONFIG.server.secretKey) {
    return res.status(500).json({ error: "SECRET_KEY not configured on server" });
  }
  if (!timingSafeEqual(provided, CONFIG.server.secretKey)) {
    return res.status(401).json({ error: "unauthorized" });
  }
  next();
}

function requireCron(req, res, next) {
  const provided =
    req.get("x-cron-secret") ||
    req.query.cron ||
    (req.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (!CONFIG.server.cronSecret) {
    return res.status(500).json({ error: "CRON_SECRET not configured on server" });
  }
  if (!timingSafeEqual(provided, CONFIG.server.cronSecret)) {
    return res.status(401).json({ error: "unauthorized" });
  }
  next();
}

function buildServer() {
  const app = express();
  app.use(express.json());
  app.disable("x-powered-by");

  // Health check (public).
  app.get("/health", (_req, res) => res.json({ ok: true, at: ts() }));

  // Public unsubscribe (one-click, no auth — validated by HMAC token).
  app.get("/unsubscribe", async (req, res) => {
    const { id, e, t } = req.query;
    const expected = makeUnsubToken(id, e);
    if (!id || !e || !timingSafeEqual(t, expected)) {
      return res.status(400).send(unsubPage("Invalid or expired unsubscribe link."));
    }
    await addSuppression(e, "unsubscribe-link");
    await updateState((st) => {
      if (st.leads[id]) st.leads[id].status = "unsubscribed";
    });
    log.info(`Unsubscribe via link: ${e}`);
    res.send(unsubPage("You have been unsubscribed. You will not be contacted again."));
  });

  // One-click POST unsubscribe (RFC 8058 List-Unsubscribe-Post).
  app.post("/unsubscribe", async (req, res) => {
    const { id, e, t } = req.query;
    const expected = makeUnsubToken(id, e);
    if (id && e && timingSafeEqual(t, expected)) {
      await addSuppression(e, "unsubscribe-oneclick");
      await updateState((st) => {
        if (st.leads[id]) st.leads[id].status = "unsubscribed";
      });
    }
    res.status(200).end();
  });

  // --- Protected control API ------------------------------------------------

  app.get("/status", requireSecret, async (_req, res) => {
    res.json(await buildStatus());
  });

  app.get("/interested", requireSecret, async (_req, res) => {
    res.json(await readJson(FILES.interested, []));
  });

  app.get("/suppression", requireSecret, async (_req, res) => {
    res.json(await readJson(FILES.suppression, []));
  });

  app.post("/run", requireSecret, async (_req, res) => {
    if (campaignRunning) return res.status(409).json({ error: "campaign already running" });
    runCampaign({ trigger: "api" }).catch((e) => log.err("bg campaign:", e.message));
    res.json({ ok: true, started: true });
  });

  app.post("/check-replies", requireSecret, async (_req, res) => {
    checkReplies().catch((e) => log.err("bg reply scan:", e.message));
    res.json({ ok: true, started: true });
  });

  // Cron-triggered endpoints (separate secret so you can wire a scheduler).
  app.post("/cron/run", requireCron, async (_req, res) => {
    if (campaignRunning) return res.status(409).json({ error: "campaign already running" });
    runCampaign({ trigger: "cron" }).catch((e) => log.err("cron campaign:", e.message));
    res.json({ ok: true, started: true });
  });

  app.post("/cron/check-replies", requireCron, async (_req, res) => {
    checkReplies().catch((e) => log.err("cron reply scan:", e.message));
    res.json({ ok: true, started: true });
  });

  // Simple HTML dashboard (protected via ?key=SECRET_KEY).
  app.get("/", requireSecret, async (_req, res) => {
    const status = await buildStatus();
    res.send(dashboardPage(status));
  });

  return app;
}

async function buildStatus() {
  const [state, leads, interested, suppression] = await Promise.all([
    readJson(FILES.state, defaultState()),
    loadLeads().catch(() => []),
    readJson(FILES.interested, []),
    readJson(FILES.suppression, []),
  ]);

  const counts = { total: leads.length, sent: 0, failed: 0, replied: 0, unsubscribed: 0, pending: 0 };
  for (const l of leads) {
    const st = state.leads?.[l.id]?.status;
    if (st === "sent" || st === "dry-run") counts.sent++;
    else if (st === "failed") counts.failed++;
    else if (st === "replied") counts.replied++;
    else if (st === "unsubscribed") counts.unsubscribed++;
    else counts.pending++;
  }

  return {
    at: ts(),
    campaignRunning,
    replyScanRunning,
    dryRun: CONFIG.campaign.dryRun,
    model: CONFIG.claudeModel,
    dailyLimit: CONFIG.campaign.dailyLimit,
    sentToday: state.daily?.[todayKey()] || 0,
    lastRunAt: state.lastRunAt,
    imapEnabled: CONFIG.imap.enabled,
    counts,
    interestedCount: interested.length,
    suppressedCount: suppression.length,
  };
}

/* ------------------------------------------------------------------ */
/* Minimal HTML pages                                                 */
/* ------------------------------------------------------------------ */

function unsubPage(message) {
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Unsubscribe</title></head>
<body style="font-family:-apple-system,Segoe UI,Roboto,sans-serif;max-width:520px;margin:80px auto;padding:0 20px;color:#1a1a1a;text-align:center">
<h1 style="font-size:20px">Unsubscribe</h1><p style="color:#555;line-height:1.6">${esc(message)}</p></body></html>`;
}

function dashboardPage(s) {
  const c = s.counts;
  const row = (label, value) =>
    `<div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #eee"><span style="color:#666">${esc(label)}</span><strong>${esc(String(value))}</strong></div>`;
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AI Sales Agent</title></head>
<body style="font-family:-apple-system,Segoe UI,Roboto,sans-serif;max-width:640px;margin:40px auto;padding:0 20px;color:#1a1a1a">
<h1 style="font-size:22px;margin-bottom:4px">AI Sales Agent</h1>
<p style="color:#888;margin-top:0;font-size:13px">${esc(s.at)}</p>
<div style="background:#fafafa;border:1px solid #eee;border-radius:12px;padding:16px 20px;margin-top:16px">
${row("Campaign running", s.campaignRunning)}
${row("Reply scan running", s.replyScanRunning)}
${row("Dry run", s.dryRun)}
${row("Model", s.model)}
${row("Daily limit", s.dailyLimit)}
${row("Sent today", s.sentToday)}
${row("Last run", s.lastRunAt || "never")}
${row("IMAP reply scan", s.imapEnabled ? "enabled" : "disabled")}
</div>
<h2 style="font-size:16px;margin-top:24px">Leads (${esc(String(c.total))})</h2>
<div style="background:#fafafa;border:1px solid #eee;border-radius:12px;padding:16px 20px">
${row("Sent", c.sent)}
${row("Replied", c.replied)}
${row("Interested", s.interestedCount)}
${row("Unsubscribed", c.unsubscribed)}
${row("Failed", c.failed)}
${row("Pending", c.pending)}
${row("Suppressed total", s.suppressedCount)}
</div>
<p style="color:#aaa;font-size:12px;margin-top:20px">POST /run, POST /check-replies with header x-secret-key.</p>
</body></html>`;
}

/* ------------------------------------------------------------------ */
/* Bootstrap                                                          */
/* ------------------------------------------------------------------ */

async function main() {
  await ensureData();

  // CLI-only reply scan mode.
  if (CONFIG.flags.checkReplies) {
    const r = await checkReplies();
    log.info("Reply scan result:", r);
    if (CONFIG.flags.exitWhenDone) process.exit(r.ok ? 0 : 1);
  }

  // CLI-only immediate campaign.
  if (CONFIG.flags.runNow) {
    const r = await runCampaign({ trigger: "cli" });
    log.info("Campaign result:", JSON.stringify(r.summary || r));
    if (CONFIG.flags.exitWhenDone) process.exit(r.ok ? 0 : 1);
  }

  // If we were asked to exit and there was nothing else, do so.
  if (CONFIG.flags.exitWhenDone && !CONFIG.flags.runNow && !CONFIG.flags.checkReplies) {
    process.exit(0);
  }

  // Otherwise, run the HTTP server.
  const app = buildServer();
  app.listen(CONFIG.server.port, () => {
    log.info(`AI sales agent listening on ${CONFIG.server.publicUrl} (port ${CONFIG.server.port})`);
    log.info(`Dashboard: ${CONFIG.server.publicUrl}/?key=YOUR_SECRET_KEY`);
    if (CONFIG.campaign.dryRun) log.warn("DRY_RUN is ON — no emails will actually be sent.");
    if (!CONFIG.imap.enabled) log.info("Reply scanning disabled. Set ENABLE_REPLY_SCAN=true to enable.");
  });
}

main().catch((e) => {
  log.err("Fatal:", e);
  process.exit(1);
});
